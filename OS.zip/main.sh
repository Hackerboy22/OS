FILE=OS.zip
if [[ -f "$FILE" ]]; then
	unzip OS.zip
	rm OS.zip
	pip install bottle
	python3 main.py
else
	pip install bottle
	python3 main.py
fi